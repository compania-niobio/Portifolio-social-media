# Super responsivo + identificação de dispositivo

Substitua estes arquivos no projeto:

- `js/modules/device.js`
- `css/responsive.css`

O `js/main.js` foi incluído apenas para conferência. Ele já chama `initDevice()`.

## O que foi adicionado

- Detecta tipo: mobile, tablet ou desktop.
- Detecta sistema: iOS, iPadOS, Android, Windows, macOS, Linux.
- Detecta marca provável: Apple, Samsung, Xiaomi, Motorola, Google etc.
- Detecta modelos prováveis:
  - iPhone 15 / 15 Pro
  - iPhone 15 Plus / 15 Pro Max
  - Samsung Galaxy S25
  - Samsung Galaxy S25+
  - Samsung Galaxy S25 Ultra
- Cria classes no HTML e no BODY, por exemplo:
  - `device-mobile`
  - `os-ios`
  - `brand-apple`
  - `model-iphone-15-ou-15-pro-provavel`
  - `orientation-portrait`
  - `viewport-phone`

## Como testar no navegador

Abra o console e rode:

```js
window.__deviceInfo
```

Depois suba:

```bash
git add .
git commit -m "adiciona responsividade e deteccao de dispositivo"
git push
```

Observação: navegadores modernos nem sempre revelam o modelo exato do aparelho. Em iPhones, a detecção é por viewport + DPR, por isso aparece como “provável”.
